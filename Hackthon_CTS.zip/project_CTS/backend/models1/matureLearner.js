const mongoose=require("mongoose")

const Schema1 = new mongoose.Schema({
    topicOfInterest: {
      type: String,
      required: true,
      
      
    },
    result: {
        type: Number,
        required: true,
        
        
      },
      learningLevel: {
        type: String,
        required: true,
        
        
      },
  });

  module.exports=new mongoose.model("InterestSet",Schema1)

  