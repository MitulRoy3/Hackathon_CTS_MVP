const express = require("express");
const mongoose = require("mongoose");

const url = "mongodb://localhost:27017/project_CTS";
const app = express();

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "http://localhost:54901/aiml/");
  res.header(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  next();
});
mongoose.connect(url, { useNewUrlParser: true });
const con = mongoose.connection;

con.on("open", () => {
  console.log("connected...");
});
app.use(express.json());
const userRouter = require("./routers/user01");
app.use("/user01", userRouter);
app.listen(9000, () => {
  console.log("Server started 9000");
});