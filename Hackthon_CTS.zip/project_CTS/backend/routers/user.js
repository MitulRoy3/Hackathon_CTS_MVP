const express = require("express");
const bcrypt = require("bcrypt");
const router = express.Router();

const loginModel = require("../models/loginModel");

router.post("/register", async (req, res) => {
    const { name, username, password } = req.body;
    try {
      if (!name   || !username || !password) {
        return res.status(400).json({ msg: "please include a name and email" });
      }
      loginModel.findOne({ username: username }).then((savedUser) => {
        if (savedUser) {
          return res.status(400).json({ msg: "user already present" });
        }
        bcrypt.hash(password, 10).then(async (hashpassword) => {
          const person = new loginModel({
            name: name,
            username: username,
            password: hashpassword,
          });
          const a1 = await person.save();
          res.json(a1);
        });
      });
    } catch (error) {
      res.send(error);
    }
  });
  module.exports=router;