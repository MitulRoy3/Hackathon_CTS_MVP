const express = require("express");
const router = express.Router();

const matureLearner = require("./models1/matureLearner");

router.post("/moduler", async (req, res) => {
    const { topicOfInterest,result,learningLevel } = req.body;
    try {
      if (!topicOfInterest || !result || !learningLevel) {
        return res.status(400).json({ msg: "please fill all the info" });
      }
        
          const person = new matureLearner ({
            opicOfInterest: topicOfInterest,
            result: result,
            learningLevel: learningLevel,
          });
          const a1 =  person.save();
          res.json(a1);
       
      
    } catch (error) {
      res.send(error);
    }
  });
  module.exports=router;