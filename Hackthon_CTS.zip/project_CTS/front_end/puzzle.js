const gameContainer = document.getElementById('gameContainer');
const recommendButton = document.getElementById('recommendButton');

const games = {
    'Memory Match': initMemoryMatchGame,
    'Jigsaw Puzzle': initJigsawPuzzleGame,
    'Word Search': initWordSearchGame,
    'Sudoku': initSudokuGame,
};

function startGame(game) {
    gameContainer.innerHTML = '';
    recommendButton.classList.add('hidden');
    games[game]();
}

function initMemoryMatchGame() {
    const cards = [
        'A', 'A', 'B', 'B', 
        'C', 'C', 'D', 'D', 
        'E', 'E', 'F', 'F', 
        'G', 'G', 'H', 'H'
    ];

    let flippedCards = [];
    let matchedCards = 0;

    function shuffle(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function createCard(content) {
        const card = document.createElement('div');
        card.classList.add('card');
        card.dataset.content = content;
        card.innerHTML = '<div class="front"></div><div class="back">' + content + '</div>';
        card.addEventListener('click', flipCard);
        return card;
    }

    function flipCard() {
        if (flippedCards.length === 2 || this.classList.contains('flipped') || this.classList.contains('matched')) {
            return;
        }

        this.classList.add('flipped');
        flippedCards.push(this);

        if (flippedCards.length === 2) {
            setTimeout(checkMatch, 1000);
        }
    }

    function checkMatch() {
        const [card1, card2] = flippedCards;
        if (card1.dataset.content === card2.dataset.content) {
            card1.classList.add('matched');
            card2.classList.add('matched');
            matchedCards += 2;
            if (matchedCards === cards.length) {
                showRecommendationButton();
            }
        } else {
            card1.classList.remove('flipped');
            card2.classList.remove('flipped');
        }
        flippedCards = [];
    }

    function initGame() {
        const shuffledCards = shuffle(cards);
        gameContainer.innerHTML = '';
        shuffledCards.forEach(content => {
            const card = createCard(content);
            gameContainer.appendChild(card);
        });
    }

    initGame();
}

function initJigsawPuzzleGame() {
    gameContainer.innerHTML = '<h2>Jigsaw Puzzle Game</h2><p>Game content coming soon...</p>';
    showRecommendationButton();
}

function initWordSearchGame() {
    gameContainer.innerHTML = '<h2>Word Search Game</h2><p>Game content coming soon...</p>';
    showRecommendationButton();
}

function initSudokuGame() {
    gameContainer.innerHTML = '<h2>Sudoku Game</h2><p>Game content coming soon...</p>';
    showRecommendationButton();
}

function showRecommendationButton() {
    recommendButton.classList.remove('hidden');
}

function getRecommendation() {
    alert('Based on your game play, we recommend trying new puzzles for more fun!');
}
