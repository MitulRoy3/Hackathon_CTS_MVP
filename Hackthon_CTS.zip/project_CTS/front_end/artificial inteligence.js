const quizContainer = document.getElementById('quizContainer');
const resultSection = document.getElementById('resultSection');
const scoreDisplay = document.getElementById('score');

const questions = [
    {
        question: "Question 1: What does AI stand for?",
        options: [" Automation", "Artificial", "Intelligence", "All"],
        answer: "Artificial"
    },
    {
        question: "Which of the following is a type of machine learning?",
        options: ["Supervised", "Unsupervised", "Reinforcement", "All"],
        answer: "All"
    },
    {
        question: "What is the primary goal of natural language processing?",
        options: ["Understanding", "Generating", "Generating","All"],
        answer: "All"
    },
    {
        question: "Which of these is a common AI application?",
        options: ["Robotics", "Painting", "Gardening", "Cooking"],
        answer: "Robotics"
    },
    {
        question: " What do we call a system that mimics human decision-making?",
        options: ["Algorithm", "Neural", "Intelligent", "Machine"],
        answer: "Intelligent"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionData = questions[currentQuestionIndex];
        const questionHtml = `
            <div class="quiz-question">
                <h3>${questionData.question}</h3>
                ${questionData.options.map(option => `
                    <div class="option" onclick="selectOption('${option}')">${option}</div>
                `).join('')}
            </div>
        `;
        quizContainer.innerHTML = questionHtml;
    } else {
        showResults();
    }
}

function selectOption(selectedOption) {
    const questionData = questions[currentQuestionIndex];
    if (selectedOption === questionData.answer) {
        score++;
    }
    currentQuestionIndex++;
    loadQuestion();
}

function showResults() {
    quizContainer.classList.add('hidden');
    resultSection.classList.remove('hidden');
    scoreDisplay.textContent = score;
}

function getRecommendation() {
    alert('Great job! Keep exploring the fascinating world of science!');
    window.location.href = `artificial inteligenceRecomm.html`;
}

loadQuestion();
