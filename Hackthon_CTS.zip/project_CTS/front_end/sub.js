function selectSubject(subject) {
    alert('You have selected ' + subject + '!');
}
