document.addEventListener('DOMContentLoaded', () => {
    const puzzleContainer = document.getElementById('puzzle-container');
    const piecesContainer = document.getElementById('pieces-container');
    const result = document.getElementById('result');
    const imageSrc = 'appi.jpeg'; // Change this to the path of your puzzle image

    // Create slots in the puzzle container
    for (let i = 0; i < 9; i++) {
        const slot = document.createElement('div');
        slot.classList.add('slot');
        slot.dataset.id = i;
        puzzleContainer.appendChild(slot);
    }

    // Create pieces in the pieces container
    const pieces = [];
    for (let i = 0; i < 9; i++) {
        const piece = document.createElement('div');
        piece.classList.add('piece');
        piece.style.backgroundImage = `url(${imageSrc})`;
        piece.style.backgroundPosition = `${-(i % 3) * 150}px ${-Math.floor(i / 3) * 150}px`;
        piece.draggable = true;
        piece.dataset.id = i;
        pieces.push(piece);
    }

    // Shuffle the pieces
    pieces.sort(() => Math.random() - 0.5);
    pieces.forEach(piece => piecesContainer.appendChild(piece));

    // Drag and drop functionality
    let draggedPiece = null;

    piecesContainer.addEventListener('dragstart', (e) => {
        draggedPiece = e.target;
    });

    puzzleContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
    });

    puzzleContainer.addEventListener('drop', (e) => {
        if (e.target.classList.contains('slot') && !e.target.hasChildNodes()) {
            e.target.appendChild(draggedPiece);
            checkPuzzleCompletion();
        }
    });

    function checkPuzzleCompletion() {
        const slots = puzzleContainer.querySelectorAll('.slot');
        let correctPieces = 0;
        slots.forEach(slot => {
            if (slot.hasChildNodes() && slot.firstChild.dataset.id == slot.dataset.id) {
                correctPieces++;
            }
        });

        if (correctPieces === 9) {
            result.textContent = 'Congratulations! You won!';
        } else {
            result.textContent = '';
        }
    }
});
