const quizContainer = document.getElementById('quizContainer');
const resultSection = document.getElementById('resultSection');
const scoreDisplay = document.getElementById('score');

const questions = [
    {
        question: " Question: What is the primary purpose of a Security Information and Event Management (SIEM) system?",
        options: ["To provide antivirus protection", "To monitor and analyze security events in real-time", "To perform vulnerability assessments", "To manage user access controls"],
        answer: "To monitor and analyze security events in real-time"
    },
    {
        question: "Which of the following is a common method used in social engineering attacks?",
        options: ["SQL Injection", "Phishing", "Cross-Site Scripting (XSS)", "Denial of Service (DoS)"],
        answer: "Phishing"
    },
    {
        question: "Which of the following vulnerabilities is mitigated by using a Web Application Firewall (WAF)?",
        options: ["SQL Injection", "Buffer Overflow", "Man-in-the-Middle Attack", "Physical Theft"],
        answer: "SQL Injection"
    },
    {
        question: "In the context of cryptography, what does the term salt refer to?",
        options: ["A type of encryption algorithm", "Random data added to passwords before hashing", "A method for key exchange", "A type of digital certificate"],
        answer: "Random data added to passwords before hashing"
    },
    {
        question: "Which protocol is commonly used to secure email communication?",
        options: ["HTTP", "FTP", "SMTP with STARTTLS", "SNMP"],
        answer: "SMTP with STARTTLS"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionData = questions[currentQuestionIndex];
        const questionHtml = `
            <div class="quiz-question">
                <h3>${questionData.question}</h3>
                ${questionData.options.map(option => `
                    <div class="option" onclick="selectOption('${option}')">${option}</div>
                `).join('')}
            </div>
        `;
        quizContainer.innerHTML = questionHtml;
    } else {
        showResults();
    }
}

function selectOption(selectedOption) {
    const questionData = questions[currentQuestionIndex];
    if (selectedOption === questionData.answer) {
        score++;
    }
    currentQuestionIndex++;
    loadQuestion();
}

function showResults() {
    quizContainer.classList.add('hidden');
    resultSection.classList.remove('hidden');
    scoreDisplay.textContent = score;
}

function getRecommendation() {
    alert('Great job! Keep exploring the fascinating world of science!');
    window.location.href = `CybersecurityRecomm.html`;
}

loadQuestion();
