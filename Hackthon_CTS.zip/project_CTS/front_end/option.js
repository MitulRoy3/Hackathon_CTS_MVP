document.addEventListener('DOMContentLoaded', function () {
    const newLearnerBox = document.getElementById('new-learner');
    const maturedLearnerBox = document.getElementById('matured-learner');

    newLearnerBox.addEventListener('click', function () {
        alert('You selected New Learner. Redirecting to registration page...');
        // Redirect to registration page
        window.location.href = 'register.html';
    });

    maturedLearnerBox.addEventListener('click', function () {
        alert('You selected Matured Learner. Redirecting to login page...');
        // Redirect to login page
        window.location.href = 'login.html';
    });
});
