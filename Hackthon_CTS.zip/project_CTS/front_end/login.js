document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('form');
    const formTitle = document.getElementById('form-title');
    const nameBox = document.getElementById('name-box');
    const toggleText = document.getElementById('toggle-text');
    const toggleForm = document.getElementById('toggle-form');

    let isRegister = true;

    toggleForm.addEventListener('click', function (event) {
        event.preventDefault();
        isRegister = !isRegister;
        if (isRegister) {
            formTitle.textContent = 'Register';
            nameBox.style.display = 'block';
            nameBox.querySelector('input').setAttribute('required', 'required');
            toggleText.innerHTML = 'Already registered? <a href="#" id="toggle-form">Login here</a>';
        } else {
            formTitle.textContent = 'Login';
            nameBox.style.display = 'none';
            nameBox.querySelector('input').removeAttribute('required');
            toggleText.innerHTML = 'Not registered? <a href="#" id="toggle-form">Register here</a>';
        }

        // Re-attach the event listener to the new link
        document.getElementById('toggle-form').addEventListener('click', toggleFormClick);
    });

    function toggleFormClick(event) {
        event.preventDefault();
        isRegister = !isRegister;
        if (isRegister) {
            formTitle.textContent = 'Register';
            nameBox.style.display = 'block';
            nameBox.querySelector('input').setAttribute('required', 'required');
            toggleText.innerHTML = 'Already registered? <a href="#" id="toggle-form">Login here</a>';
        } else {
            formTitle.textContent = 'Login';
            nameBox.style.display = 'none';
            nameBox.querySelector('input').removeAttribute('required');
            toggleText.innerHTML = 'Not registered? <a href="#" id="toggle-form">Register here</a>';
        }

        // Re-attach the event listener to the new link
        document.getElementById('toggle-form').addEventListener('click', toggleFormClick);
    }

    document.getElementById('toggle-form').addEventListener('click', toggleFormClick);

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const username = form.username.value;
        const password = form.password.value;
        const name = isRegister ? form.name.value : null;

        if (username && password && (!isRegister || name)) {
            if (isRegister) {
                alert(`Welcome, ${name}! Registration successful.`);
                // Here you can add logic to handle registration,
                // such as sending data to a server or storing it locally.
            } else {
                alert('Login successful!');
                // Here you can add logic to handle login,
                // such as validating credentials or redirecting the user.
            }
        } else {
            alert('Please fill in all required fields.');
        }
    });
});
