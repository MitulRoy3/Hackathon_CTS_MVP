document.addEventListener('DOMContentLoaded', () => {
    const yesButton = document.querySelector('.yes');
    const noButton = document.querySelector('.no');

    yesButton.addEventListener('click', () => {
        speak('Great! Let\'s have some fun!');
    });

    noButton.addEventListener('click', () => {
        speak('Welcome lets solve some quis!');
    });

    // Start voice recognition
    startRecognition();

    function speak(text) {
        const speech = new SpeechSynthesisUtterance();
        speech.lang = "en-US";
        speech.text = text;
        speech.volume = 1;
        speech.rate = 1;
        speech.pitch = 1;
        window.speechSynthesis.speak(speech);
    }

    function startRecognition() {
        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = 'en-US';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        recognition.start();

        recognition.onresult = (event) => {
            const speechResult = event.results[0][0].transcript.toLowerCase();
            if (speechResult.includes('yes')) {
                yesButton.click();
            } else if (speechResult.includes('no')) {
                noButton.click();
            }
        };

        recognition.onspeechend = () => {
            recognition.stop();
        };

        recognition.onerror = (event) => {
            console.error('Error occurred in recognition: ', event.error);
        };

        recognition.onend = () => {
            // Restart recognition after it ends
            recognition.start();
        };
    }
});
