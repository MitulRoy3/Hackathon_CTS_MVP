document.addEventListener('DOMContentLoaded', (event) => {
    const startBtn = document.getElementById('start-btn');
    const recommendBtn = document.getElementById('recommend-btn');
    const resultDiv = document.getElementById('result');
    const gameImage = document.getElementById('game-image');
    const scoreDiv = document.getElementById('score');
    const recommendationDiv = document.getElementById('recommendation');
    
    const images = [
        { src: 'apple.jpeg', name: 'apple' },
        { src: 'dog.jpeg', name: 'dog' },
        { src: 'cat.jpeg', name: 'cat' }
    ];
    
    let usedImages = [];
    let score = 0;

    startBtn.addEventListener('click', () => {
        resultDiv.textContent = '';
        recommendationDiv.textContent = '';
        recommendBtn.disabled = true;
        usedImages = [];
        score = 0;
        scoreDiv.textContent = `Score: ${score}`;
        startGame();
    });

    recommendBtn.addEventListener('click', () => {
        showRecommendation(score);
    });

    function startGame() {
        if (usedImages.length === images.length) {
            recommendBtn.disabled = false;
            return;
        }

        const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        recognition.lang = 'en-US';
        recognition.start();

        recognition.onstart = function() {
            startBtn.disabled = true;
        };

        recognition.onresult = function(event) {
            const spokenText = event.results[0][0].transcript.toLowerCase();
            const currentImage = images[usedImages.length];
            const correctAnswer = currentImage.name;
            if (spokenText.includes(correctAnswer)) {
                resultDiv.textContent = 'Correct!';
                resultDiv.style.color = 'green';
                score += 10;
            } else {
                resultDiv.textContent = 'Try Again!';
                resultDiv.style.color = 'red';
            }
            scoreDiv.textContent = `Score: ${score}`;
            usedImages.push(currentImage);

            if (usedImages.length < images.length) {
                gameImage.src = images[usedImages.length].src;
                startGame();
            } else {
                recommendBtn.disabled = false;
            }
        };

        recognition.onerror = function(event) {
            resultDiv.textContent = 'Error occurred in recognition: ' + event.error;
            startBtn.disabled = false;
        };
    }

    function showRecommendation(score) {
        if (score >= 20) {
            recommendationDiv.textContent = 'Great job! You did amazing!';
        } else if (score >= 10) {
            recommendationDiv.textContent = 'Good effort! Keep practicing!';
        } else {
            recommendationDiv.textContent = 'Keep trying! You will get better!';
        }
    }
});
