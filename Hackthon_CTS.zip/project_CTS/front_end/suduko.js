document.addEventListener('DOMContentLoaded', () => {
    const sudokuGrid = document.getElementById('sudoku-grid');
    const checkSolutionButton = document.getElementById('check-solution');

    // Initial Sudoku puzzle (0 represents empty cells)
    const puzzle = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ];

    // Function to create the Sudoku grid
    function createGrid() {
        for (let row = 0; row < 9; row++) {
            for (let col = 0; col < 9; col++) {
                const cell = document.createElement('div');
                cell.classList.add('cell');

                const input = document.createElement('input');
                input.type = 'text';
                input.maxLength = 1;

                if (puzzle[row][col] !== 0) {
                    input.value = puzzle[row][col];
                    input.disabled = true;
                }

                cell.appendChild(input);
                sudokuGrid.appendChild(cell);
            }
        }
    }

    // Function to check the solution
    function checkSolution() {
        const cells = sudokuGrid.getElementsByClassName('cell');
        let solutionIsValid = true;

        // Convert the current grid to a 2D array
        const currentGrid = [];
        for (let i = 0; i < 9; i++) {
            currentGrid.push([]);
        }

        for (let i = 0; i < cells.length; i++) {
            const cell = cells[i];
            const input = cell.firstChild;
            const value = parseInt(input.value);

            const row = Math.floor(i / 9);
            const col = i % 9;

            if (isNaN(value) || value < 1 || value > 9) {
                solutionIsValid = false;
                break;
            }

            currentGrid[row][col] = value;
        }

        if (solutionIsValid && validateSudoku(currentGrid)) {
            alert('Congratulations! You are a winner!');
        } else {
            alert('The solution is not correct. Please try again.');
        }
    }

    // Function to validate the Sudoku solution
    function validateSudoku(grid) {
        for (let i = 0; i < 9; i++) {
            if (!validateRow(grid, i) || !validateColumn(grid, i) || !validateBox(grid, i)) {
                return false;
            }
        }
        return true;
    }

    function validateRow(grid, row) {
        const seen = new Set();
        for (let col = 0; col < 9; col++) {
            const value = grid[row][col];
            if (seen.has(value)) {
                return false;
            }
            seen.add(value);
        }
        return true;
    }

    function validateColumn(grid, col) {
        const seen = new Set();
        for (let row = 0; row < 9; row++) {
            const value = grid[row][col];
            if (seen.has(value)) {
                return false;
            }
            seen.add(value);
        }
        return true;
    }

    function validateBox(grid, box) {
        const seen = new Set();
        const startRow = Math.floor(box / 3) * 3;
        const startCol = (box % 3) * 3;

        for (let i = 0; i < 3; i++) {
            for (let j = 0; j < 3; j++) {
                const value = grid[startRow + i][startCol + j];
                if (seen.has(value)) {
                    return false;
                }
                seen.add(value);
            }
        }
        return true;
    }

    // Create the grid on page load
    createGrid();

    // Add event listener to the check solution button
    checkSolutionButton.addEventListener('click', checkSolution);
});
