document.getElementById('recommendButton').addEventListener('click', function() {
    // Display the recommendation
    document.getElementById('recommendation').classList.remove('hidden');
});

document.getElementById('downloadButton').addEventListener('click', function() {
    // Download the template
    const link = document.createElement('a');
    link.href = 'path/to/recommended/template.pdf'; // Replace with the path to your recommended template
    link.download = 'recommended_template.pdf';
    link.click();

    // Redirect to course details page
    window.location.href = 'https://www.recommendedcoursedetailspage.com'; // Replace with your recommended course details URL
});
