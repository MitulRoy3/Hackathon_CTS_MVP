const quizContainer = document.getElementById('quizContainer');
const resultSection = document.getElementById('resultSection');
const scoreDisplay = document.getElementById('score');

const questions = [
    {
        question: "What is the derivative of x^2?",
        options: ["2x", "x^2", "2", "x"],
        answer: "2x"
    },
    {
        question: "What is the integral of 1/x?",
        options: ["ln(x)", "1/x^2", "x", "e^x"],
        answer: "ln(x)"
    },
    {
        question: "What is the value of e^(iπ) + 1?",
        options: ["0", "1", "-1", "π"],
        answer: "0"
    },
    {
        question: "What is the solution to the differential equation dy/dx = y?",
        options: ["e^x", "e^(2x)", "x^2", "y = x"],
        answer: "e^x"
    },
    {
        question: "What is the determinant of the matrix [[1, 2], [3, 4]]?",
        options: ["-2", "2", "4", "-4"],
        answer: "-2"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionData = questions[currentQuestionIndex];
        const questionHtml = `
            <div class="quiz-question">
                <h3>${questionData.question}</h3>
                ${questionData.options.map(option => `
                    <div class="option" onclick="selectOption('${option}')">${option}</div>
                `).join('')}
            </div>
        `;
        quizContainer.innerHTML = questionHtml;
    } else {
        showResults();
    }
}

function selectOption(selectedOption) {
    const questionData = questions[currentQuestionIndex];
    if (selectedOption === questionData.answer) {
        score++;
    }
    currentQuestionIndex++;
    loadQuestion();
}

function showResults() {
    quizContainer.classList.add('hidden');
    resultSection.classList.remove('hidden');
    scoreDisplay.textContent = score;
}

function getRecommendation() {
    alert('Great job! Keep practicing advanced mathematics to enhance your skills.');
}

loadQuestion();
