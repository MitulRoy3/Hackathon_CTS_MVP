const quizContainer = document.getElementById('quizContainer');
const resultSection = document.getElementById('resultSection');
const scoreDisplay = document.getElementById('score');

const questions = [
    {
        question: "What is the function of a diode?",
        options: ["To store energy", "To allow current in one direction", "To amplify signals", "To resist current flow"],
        answer: "To allow current in one direction"
    },
    {
        question: "What is the unit of capacitance?",
        options: ["Henry", "Ohm", "Farad", "Volt"],
        answer: "Farad"
    },
    {
        question: "What is the modulation technique used in AM radio?",
        options: ["Frequency Modulation", "Phase Modulation", "Amplitude Modulation", "Pulse Code Modulation"],
        answer: "Amplitude Modulation"
    },
    {
        question: "What does LED stand for?",
        options: ["Light Emitting Diode", "Light Emission Device", "Low Emission Diode", "Light Emitting Device"],
        answer: "Light Emitting Diode"
    },
    {
        question: "What is the primary purpose of an antenna in telecommunication?",
        options: ["To amplify signals", "To store data", "To transmit and receive signals", "To convert digital to analog signals"],
        answer: "To transmit and receive signals"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionData = questions[currentQuestionIndex];
        const questionHtml = `
            <div class="quiz-question">
                <h3>${questionData.question}</h3>
                ${questionData.options.map(option => `
                    <div class="option" onclick="selectOption('${option}')">${option}</div>
                `).join('')}
            </div>
        `;
        quizContainer.innerHTML = questionHtml;
    } else {
        showResults();
    }
}

function selectOption(selectedOption) {
    const questionData = questions[currentQuestionIndex];
    if (selectedOption === questionData.answer) {
        score++;
    }
    currentQuestionIndex++;
    loadQuestion();
}

function showResults() {
    quizContainer.classList.add('hidden');
    resultSection.classList.remove('hidden');
    scoreDisplay.textContent = score;
}

function getRecommendation() {
    alert('Great job! Keep up with your studies in electronics and telecommunication engineering!');
}

loadQuestion();
