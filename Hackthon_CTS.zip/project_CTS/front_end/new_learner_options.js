document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('image-recognition').addEventListener('click', () => {
        window.location.href = 'image-recognition.html';
    });
    document.getElementById('puzzle-games').addEventListener('click', () => {
        window.location.href = 'puzzle-games.html';
    });
    document.getElementById('voice-assistant').addEventListener('click', () => {
        window.location.href = 'voice-assistant.html';
    });
});
