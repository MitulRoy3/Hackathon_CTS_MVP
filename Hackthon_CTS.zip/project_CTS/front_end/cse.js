const quizContainer = document.getElementById('quizContainer');
const resultSection = document.getElementById('resultSection');
const scoreDisplay = document.getElementById('score');

const questions = [
    {
        question: "What is the time complexity of binary search?",
        options: ["O(n)", "O(log n)", "O(n log n)", "O(n^2)"],
        answer: "O(log n)"
    },
    {
        question: "Which data structure is used for implementing recursion?",
        options: ["Queue", "Stack", "Linked List", "Tree"],
        answer: "Stack"
    },
    {
        question: "What is the output of the following code? int x = 10; System.out.println(++x);",
        options: ["10", "11", "9", "Error"],
        answer: "11"
    },
    {
        question: "What does HTTP stand for?",
        options: ["Hypertext Transfer Protocol", "Hypertext Transfer Package", "Hyperlink Transfer Protocol", "Hyperlink Text Protocol"],
        answer: "Hypertext Transfer Protocol"
    },
    {
        question: "Which of the following is not a programming language?",
        options: ["Python", "HTML", "Java", "C++"],
        answer: "HTML"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function loadQuestion() {
    if (currentQuestionIndex < questions.length) {
        const questionData = questions[currentQuestionIndex];
        const questionHtml = `
            <div class="quiz-question">
                <h3>${questionData.question}</h3>
                ${questionData.options.map(option => `
                    <div class="option" onclick="selectOption('${option}')">${option}</div>
                `).join('')}
            </div>
        `;
        quizContainer.innerHTML = questionHtml;
    } else {
        showResults();
    }
}

function selectOption(selectedOption) {
    const questionData = questions[currentQuestionIndex];
    if (selectedOption === questionData.answer) {
        score++;
    }
    currentQuestionIndex++;
    loadQuestion();
}

function showResults() {
    quizContainer.classList.add('hidden');
    resultSection.classList.remove('hidden');
    scoreDisplay.textContent = score;
}

function getRecommendation() {
    alert('Great job! Keep up with your studies in computer science engineering!');
}

loadQuestion();
