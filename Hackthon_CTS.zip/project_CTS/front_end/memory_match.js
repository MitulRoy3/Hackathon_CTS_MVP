const gameBoard = document.getElementById('gameBoard');

const cards = [
    'A', 'A', 'B', 'B', 
    'C', 'C', 'D', 'D', 
    'E', 'E', 'F', 'F', 
    'G', 'G', 'H', 'H'
];

let flippedCards = [];
let matchedCards = 0;

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function createCard(content) {
    const card = document.createElement('div');
    card.classList.add('card');
    card.dataset.content = content;
    card.innerHTML = '<div class="front"></div><div class="back">' + content + '</div>';
    card.addEventListener('click', flipCard);
    return card;
}

function flipCard() {
    if (flippedCards.length === 2 || this.classList.contains('flipped') || this.classList.contains('matched')) {
        return;
    }

    this.classList.add('flipped');
    flippedCards.push(this);

    if (flippedCards.length === 2) {
        setTimeout(checkMatch, 1000);
    }
}

function checkMatch() {
    const [card1, card2] = flippedCards;
    if (card1.dataset.content === card2.dataset.content) {
        card1.classList.add('matched');
        card2.classList.add('matched');
        matchedCards += 2;
        if (matchedCards === cards.length) {
            alert('You win!');
        }
    } else {
        card1.classList.remove('flipped');
        card2.classList.remove('flipped');
    }
    flippedCards = [];
}

function initGame() {
    const shuffledCards = shuffle(cards);
    gameBoard.innerHTML = '';
    shuffledCards.forEach(content => {
        const card = createCard(content);
        gameBoard.appendChild(card);
    });
}

initGame();
