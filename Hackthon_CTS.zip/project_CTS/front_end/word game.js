document.addEventListener('DOMContentLoaded', () => {
    const wordSearchContainer = document.getElementById('word-search-container');
    const wordListContainer = document.getElementById('word-list');
    const result = document.getElementById('result');
    const words = ['CAT', 'DOG', 'FISH', 'BIRD', 'COW'];
    const gridSize = 6;
    let selectedCells = [];
    let foundWords = new Set();

    // Create the word search grid
    const grid = Array(gridSize).fill(null).map(() => Array(gridSize).fill(''));
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

    function placeWord(word) {
        const directions = [
            { x: 1, y: 0 },
            { x: 0, y: 1 },
            { x: 1, y: 1 },
            { x: -1, y: 1 }
        ];

        let placed = false;
        while (!placed) {
            const direction = directions[Math.floor(Math.random() * directions.length)];
            const startX = Math.floor(Math.random() * gridSize);
            const startY = Math.floor(Math.random() * gridSize);

            if (canPlaceWord(word, startX, startY, direction)) {
                for (let i = 0; i < word.length; i++) {
                    const x = startX + i * direction.x;
                    const y = startY + i * direction.y;
                    grid[y][x] = word[i];
                }
                placed = true;
            }
        }
    }

    function canPlaceWord(word, startX, startY, direction) {
        for (let i = 0; i < word.length; i++) {
            const x = startX + i * direction.x;
            const y = startY + i * direction.y;

            if (x < 0 || x >= gridSize || y < 0 || y >= gridSize || (grid[y][x] !== '' && grid[y][x] !== word[i])) {
                return false;
            }
        }
        return true;
    }

    words.forEach(word => placeWord(word));

    // Fill empty cells with random letters
    for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
            if (grid[y][x] === '') {
                grid[y][x] = alphabet[Math.floor(Math.random() * alphabet.length)];
            }
        }
    }

    // Display the grid
    grid.forEach((row, y) => {
        row.forEach((letter, x) => {
            const cell = document.createElement('div');
            cell.classList.add('grid-cell');
            cell.textContent = letter;
            cell.dataset.x = x;
            cell.dataset.y = y;
            wordSearchContainer.appendChild(cell);
        });
    });

    // Display the word list
    words.forEach(word => {
        const listItem = document.createElement('li');
        listItem.textContent = word;
        wordListContainer.appendChild(listItem);
    });

    wordSearchContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('grid-cell')) {
            e.target.classList.toggle('selected');
            const x = e.target.dataset.x;
            const y = e.target.dataset.y;
            const cellId = `${x}-${y}`;

            if (selectedCells.includes(cellId)) {
                selectedCells = selectedCells.filter(id => id !== cellId);
            } else {
                selectedCells.push(cellId);
            }

            checkSelectedCells();
        }
    });

    function checkSelectedCells() {
        const selectedWord = selectedCells.map(id => {
            const [x, y] = id.split('-');
            return grid[y][x];
        }).join('');

        if (words.includes(selectedWord)) {
            foundWords.add(selectedWord);
            selectedCells.forEach(id => {
                const [x, y] = id.split('-');
                const cell = wordSearchContainer.querySelector(`.grid-cell[data-x='${x}'][data-y='${y}']`);
                cell.classList.add('found');
                cell.classList.remove('selected');
            });

            selectedCells = [];
            checkWinCondition();
        }
    }

    function checkWinCondition() {
        if (foundWords.size === words.length) {
            result.textContent = 'Congratulations! You are a winner!';
            alert('Congratulations! You found all the words!');
        }
    }
});
